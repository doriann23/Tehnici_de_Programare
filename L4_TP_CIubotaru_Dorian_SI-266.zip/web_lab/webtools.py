# Laborator: funcții, metode și importuri pe web
# Student: <Ciubotaru Dorian>

import requests
import urllib.parse
import re
import socket
import ssl
import time
import json

TIMEOUT = 10
# Exercițiul 47. Constante de modul
DEFAULT_HEADERS = {"User-Agent": "WebLab-CiubotaruDorian"}


def fetch(url, timeout=TIMEOUT):
    # Am adăugat headers=DEFAULT_HEADERS conform cerinței 47
    return requests.get(url, timeout=timeout, headers=DEFAULT_HEADERS)

def get_status(url):
    return requests.get(url, timeout=TIMEOUT, headers=DEFAULT_HEADERS).status_code

def get_title(html):
    start = html.find("<title>")
    if start != -1:
        start += len("<title>")
        end = html.find("</title>")
        return html[start:end].strip()
    return "Fără titlu"

def security_headers(url):
    rezultat = {}
    antete_cautate = ["Strict-Transport-Security", "Content-Security-Policy", "X-Frame-Options", "X-Content-Type-Options", "Referrer-Policy"]
    try:
        response = requests.head(url, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
        for antet in antete_cautate:
            rezultat[antet] = antet in response.headers
    except requests.RequestException:
        for antet in antete_cautate:
            rezultat[antet] = False
    return rezultat

def score_headers(results: dict) -> str:
    total = len(results)
    gasite = sum(results.values())
    return f"{gasite}/{total}"

def check_paths(base, paths):
    rezultat = {}
    for cale in paths:
        try:
            response = requests.get(base + cale, timeout=TIMEOUT, headers=DEFAULT_HEADERS)
            rezultat[cale] = response.status_code
        except requests.RequestException:
            rezultat[cale] = None
        time.sleep(1)
    return rezultat

def resolve(hostname):
    return socket.gethostbyname(hostname)

def cert_days_left(hostname):
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            cert = ssock.getpeercert()
            expire_timestamp = ssl.cert_time_to_seconds(cert["notAfter"])
            return int((expire_timestamp - time.time()) / 86400)

def extract_links(html):
    links = re.findall(r'href="([^"]+)"', html)
    return list(set(links))

def split_links(links, domain):
    interne, externe = [], []
    for link in links:
        full_url = urllib.parse.urljoin(f"https://{domain}", link)
        if urllib.parse.urlparse(full_url).netloc == domain:
            interne.append(full_url)
        else:
            externe.append(full_url)
    return interne, externe

def fetch_robots(base):
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT, headers=DEFAULT_HEADERS)
        if response.status_code == 200:
            return response.text
        return None
    except requests.RequestException:
        return None

def disallowed_paths(robots_text):
    if not robots_text:
        return []
    cai = []
    for linie in robots_text.splitlines():
        if linie.strip().lower().startswith("disallow:"):
            cai.append(linie.split(":", 1)[1].strip())
    return cai

# Exercițiul 50. Proiect final: raportul site-ului
def site_report(url):
    parsed = urllib.parse.urlparse(url)
    domain = parsed.netloc

    # Colectăm datele folosind funcțiile de mai sus
    response = fetch(url)
    status_code = response.status_code
    final_url = response.url
    title = get_title(response.text)

    ip_addr = resolve(domain)

    # Redirecționări pornind de la http://
    http_resp = requests.get(f"http://{domain}", timeout=TIMEOUT, headers=DEFAULT_HEADERS)
    redirects_list = [f"{r.status_code} -> {r.url}" for r in http_resp.history]
    redirect_str = ", ".join(redirects_list) if redirects_list else "Fără redirecționări"

    sec_score = score_headers(security_headers(url))
    cert_days = cert_days_left(domain)

    links = extract_links(response.text)
    interne, externe = split_links(links, domain)

    robots_txt = fetch_robots(f"https://{domain}")
    disallowed = disallowed_paths(robots_txt)
    disallowed_str = ", ".join(disallowed) if disallowed else "Niciuna"

    # Afișarea raportului în consolă
    print(f"=== Raport site: {url} ===")
    print(f"Cod de stare:      {status_code}")
    print(f"Titlu:             {title}")
    print(f"Adresă IP:         {ip_addr}")
    print(f"Redirecționări:    {redirect_str}")
    print(f"Scor securitate:   {sec_score}")
    print(f"Certificat:        {cert_days} de zile rămase")
    print(f"Legături:          {len(interne)} interne, {len(externe)} externe")
    print(f"Căi interzise:     {disallowed_str}")

    # Salvarea în JSON
    date_json = {
        "status_code": status_code,
        "final_url": final_url,
        "title": title,
        "ip_address": ip_addr,
        "redirects": redirects_list,
        "security_score": sec_score,
        "cert_days_left": cert_days,
        "links": {"internal": len(interne), "external": len(externe)},
        "disallowed_paths": disallowed
    }
    with open("report.json", "w") as f:
        json.dump(date_json, f, indent=4)
    print("Salvat în report.json")

# Exercițiul 46. Blocul main (Autotest)
if __name__ == "__main__":
    print("\nExercițiul 46")
    print("Autotest:", get_status("https://cybercor.org"))