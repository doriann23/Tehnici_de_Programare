# Laborator: funcții, metode și importuri pe web
# Student: <Ciubotaru Dorian>

import requests
import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 21. Prima funcție

print("\nExercițiul 21")
def fetch(url):
    """Returnează obiectul răspuns pentru un URL dat."""
    response = requests.get(url, timeout=TIMEOUT)
    return response

raspuns = fetch(BASE_URL)
print("Cod de stare (funcția fetch):", raspuns.status_code)

time.sleep(1)


# Exercițiul 22. Returnarea unei singure valori

print("\nExercițiul 22")
def get_status(url):
    """Returnează codul de stare HTTP pentru adresa url."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

cai = ["/", "/robots.txt", "/sitemap.xml"]
for cale in cai:
    url_complet = BASE_URL + cale
    print(f"Cod de stare pentru {cale}:", get_status(url_complet))
    time.sleep(1)


# Exercițiul 23. Parametri impliciți

print("\nExercițiul 23")
# Redefinim funcția fetch pentru a adăuga valoarea implicită timeout=10
def fetch(url, timeout=10):
    """Returnează obiectul răspuns, având timeout implicit de 10 secunde."""
    response = requests.get(url, timeout=timeout)
    return response

print("Cerere cu timeout implicit (10s), status:", fetch(BASE_URL).status_code)
time.sleep(1)
print("Cerere cu timeout explicit (3s), status:", fetch(BASE_URL, timeout=3).status_code)

time.sleep(1)


# Exercițiul 24. O singură sarcină pe funcție

print("\nExercițiul 24")
def get_title(html):
    """Extrage și returnează titlul din codul HTML primit."""
    start = html.find("<title>")
    if start != -1:
        start += len("<title>")
        end = html.find("</title>")
        return html[start:end].strip()
    return "Fără titlu"

html_extras = fetch(BASE_URL).text
print("Titlul extras este:", get_title(html_extras))

time.sleep(1)


# Exercițiul 25. Docstring-uri

print("\nExercițiul 25")
help(get_title)


# Exercițiul 26. Adnotări de tip

print("\nExercițiul 26")
# Redefinim cu type hints (adnotări de tip)
def get_status(url: str) -> int:
    """Returnează codul de stare HTTP pentru adresa url (folosind type hints)."""
    response = requests.get(url, timeout=TIMEOUT)
    return response.status_code

try:
    get_status(123)
except Exception as e:
    print(f"Eroare prinsă: {type(e).__name__}")

# Adnotările de tip (ex: url: str) NU opresc execuția programului dacă folosim tipul greșit.
# Sunt doar sugestii pentru programatori. Eroarea efectivă este generată de 'requests',
# care nu știe să citească numărul 123 ca URL.


# Exercițiul 27. Fără opriri neașteptate

print("\nExercițiul 27")
def page_exists(url: str) -> bool:
    """Verifică dacă o pagină există returnând True sau False, tratând erorile."""
    try:
        response = requests.get(url, timeout=TIMEOUT)
        return response.ok
    except requests.RequestException:
        return False

url_inexistent = "https://this-domain-does-not-exist.invalid"
print(f"Există {url_inexistent}? :", page_exists(url_inexistent))

time.sleep(1)


# Exercițiul 28. Returnarea unui dicționar

print("\nExercițiul 28")
def check_paths(base: str, paths: list) -> dict:
    """Returnează un dicționar {path: status_code} pentru o listă de căi."""
    rezultat = {}
    for cale in paths:
        url_complet = base + cale
        try:
            response = requests.get(url_complet, timeout=TIMEOUT)
            rezultat[cale] = response.status_code
        except requests.RequestException:
            rezultat[cale] = None
        time.sleep(1)
    return rezultat

cai_de_verificat = ["/", "/robots.txt", "/sitemap.xml"]
print("Status căi:", check_paths(BASE_URL, cai_de_verificat))


# Exercițiul 29. Argumente cu nume

print("\nExercițiul 29")
def get_header(url: str, name: str, default: str = "lipsește") -> str:
    """Aduce valoarea unui anumit antet HTTP, cu posibilitatea unei valori implicite."""
    try:
        response = requests.head(url, timeout=TIMEOUT)
        return response.headers.get(name, default)
    except requests.RequestException:
        return default

print("Verificăm antetul Server:", get_header(BASE_URL, name="Server"))

time.sleep(1)


# Exercițiul 30. Antete de securitate

print("\nExercițiul 30")
def security_headers(url: str) -> dict:
    """Verifică prezența a 5 antete importante de securitate."""
    rezultat = {}
    antete_cautate = [
        "Strict-Transport-Security",
        "Content-Security-Policy",
        "X-Frame-Options",
        "X-Content-Type-Options",
        "Referrer-Policy"
    ]
    try:
        response = requests.head(url, timeout=TIMEOUT)
        for antet in antete_cautate:
            rezultat[antet] = antet in response.headers
    except requests.RequestException:
        for antet in antete_cautate:
            rezultat[antet] = False
    return rezultat

rezultate_securitate = security_headers(BASE_URL)
print("Antete de securitate găsite:", rezultate_securitate)

time.sleep(1)


# Exercițiul 31. Funcții care apelează funcții

print("\nExercițiul 31")
def score_headers(results: dict) -> str:
    """Returnează un scor sub formă de text 'găsite/total' (ex: '3/5')."""
    total = len(results)
    gasite = sum(results.values())
    return f"{gasite}/{total}"

scor = score_headers(security_headers(BASE_URL))
print("Scorul antetelor de securitate:", scor)

time.sleep(1)


# Exercițiul 32. Două funcții, o sarcină

print("\nExercițiul 32")
def fetch_robots(base: str) -> str:
    """Returnează textul fișierului robots.txt sau None."""
    try:
        response = requests.get(base + "/robots.txt", timeout=TIMEOUT)
        if response.status_code == 200:
            return response.text
        return None
    except requests.RequestException:
        return None

def disallowed_paths(robots_text: str) -> list:
    """Returnează o listă cu valorile Disallow: din fișierul robots.txt."""
    if not robots_text:
        return []
    cai = []
    for linie in robots_text.splitlines():
        if linie.strip().lower().startswith("disallow:"):
            valoare = linie.split(":", 1)[1].strip()
            cai.append(valoare)
    return cai

text_robots = fetch_robots(BASE_URL)
lista_cai_interzise = disallowed_paths(text_robots)
print("Căi interzise în robots.txt:", lista_cai_interzise)

time.sleep(1)


# Exercițiul 33. Oricâte argumente

print("\nExercițiul 33")
def response_times(*urls: str) -> dict:
    """Măsoară timpul de răspuns pentru un număr variabil de URL-uri."""
    timpi = {}
    for url in urls:
        start = time.perf_counter()
        try:
            requests.head(url, timeout=TIMEOUT)
            end = time.perf_counter()
            timpi[url] = round(end - start, 3)
        except requests.RequestException:
            timpi[url] = None
        time.sleep(1)
    return timpi

print("Timp de răspuns comparativ:", response_times(BASE_URL, ECHO_URL))


# Exercițiul 34. Argumente cu nume colectate

print("\nExercițiul 34")
def log(message: str, **details):
    """Afișează mesajul principal urmat de fiecare detaliu separat cu bara verticală."""
    bucati = [message]
    for cheie, valoare in details.items():
        bucati.append(f"{cheie}={valoare}")
    print(" | ".join(bucati))

log("verificat", url=BASE_URL, status=200)



# Verificați-vă:
# Diferența dintre a afișa o valoare cu print() și a o returna cu return:
# print() doar scrie o valoare pe ecran, dar nu o păstrează în memoria programului pentru a fi refolosită.
# return trimite valoarea înapoi de unde a fost apelată funcția, permițând salvarea ei într-o variabilă
# sau utilizarea ei în alte calcule (cum am făcut cu funcțiile înlănțuite la Exercițiul 31).