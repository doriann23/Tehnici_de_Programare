# Laborator: funcții, metode și importuri pe web
# Student: <Ciubotaru Dorian>

import argparse
import csv
from datetime import datetime

# Exercițiul 44 și 45. Importarea anumitor nume
from webtools import fetch, get_title, check_paths, site_report, DEFAULT_HEADERS




print("\nExercițiul 47")
print("Constanta importată DEFAULT_HEADERS este:", DEFAULT_HEADERS)

# Exercițiul 48. Argumente din linia de comandă
if __name__ == "__main__":
    # Configurăm argparse pentru a citi URL-ul din comandă
    parser = argparse.ArgumentParser(description="Audit pentru un site web.")
    parser.add_argument("url", help="URL-ul site-ului de verificat (ex: https://cybercor.org)")
    args = parser.parse_args()

    target_url = args.url

    print("\nExercițiul 49. Un raport CSV")
    # Salvăm rezultatul verificării căilor în report.csv
    paths = ["/", "/robots.txt", "/sitemap.xml"]
    rezultate_paths = check_paths(target_url, paths)

    with open("report.csv", "w", newline='') as f:
        writer = csv.writer(f)
        writer.writerow(["path", "status", "checked_at"])
        for path, status in rezultate_paths.items():
            writer.writerow([path, status, datetime.now().isoformat()])
    print("Fișierul report.csv a fost creat cu succes.")

    print("\nExercițiul 50. Proiect final: raportul site-ului")
    # Generăm raportul complet
    site_report(target_url)