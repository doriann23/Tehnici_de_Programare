# Laborator: funcții, metode și importuri pe web
# Student: <Ciubotaru Dorian>

import time
import requests

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 9. Elementele de bază ale răspunsului

print("\nExercițiul 9")
response = requests.get(BASE_URL, timeout=TIMEOUT)

print("Cod de stare:", response.status_code) # atribut
print("Este OK?:", response.ok)              # atribut
print("URL final:", response.url)            # atribut
print("Codificare:", response.encoding)      # atribut

time.sleep(1)


# Exercițiul 10. Tratarea erorilor cu o metodă

print("\nExercițiul 10")
response.raise_for_status()

try:
    bad_response = requests.get(BASE_URL + "/pagina-inexistenta", timeout=TIMEOUT)
    bad_response.raise_for_status()
except requests.HTTPError:
    print("Eroare prinsă cu succes: Pagina nu a fost găsită pe server!")

time.sleep(1)


# Exercițiul 11. Toate antetele

print("\nExercițiul 11")
for nume, valoare in response.headers.items():
    print(f"{nume}: {valoare}")


# Exercițiul 12. Metode de dicționar

print("\nExercițiul 12")
print("Server:", response.headers.get("Server", "lipsește"))
print("Content-Type (majuscule):", response.headers.get("Content-Type", "lipsește"))
print("content-type (minuscule):", response.headers.get("content-type", "lipsește"))

# Dicționarul de antete din requests este case-insensitive,
# deci returnează aceeași valoare indiferent dacă scriem cheia cu majuscule sau minuscule.


# Exercițiul 13. Înlănțuirea metodelor de șir

print("\nExercițiul 13")
aparitii = response.text.lower().count("cyber")
print("Număr apariții 'cyber':", aparitii)

# Putem înlănțui .lower() și .count() deoarece .lower() returnează
# un nou șir de caractere (string), iar pe acesta putem aplica direct .count().


# Exercițiul 14. Găsirea titlului

print("\nExercițiul 14")
html = response.text
start = html.find("<title>") + len("<title>")
end = html.find("</title>")
titlu = html[start:end].strip()
print("Titlul paginii este:", titlu)


# Exercițiul 15. Numărarea liniilor

print("\nExercițiul 15")
lines = response.text.splitlines()
print("Număr total de linii:", len(lines))
cea_mai_lunga = max(lines, key=len)
print("Lungimea celei mai lungi linii:", len(cea_mai_lunga))


# Exercițiul 16. Verificarea HTTPS

print("\nExercițiul 16")
if response.url.startswith("https://"):
    print("Conexiunea este securizată (HTTPS)")
else:
    print("Conexiunea nu este securizată")


# Exercițiul 17. Urmărirea redirecționărilor

print("\nExercițiul 17")
response_http = requests.get("http://cybercor.org", timeout=TIMEOUT)
for resp in response_http.history:
    print(f"Redirecționare: {resp.status_code} -> {resp.url}")
print("URL final:", response_http.url)

time.sleep(1)


# Exercițiul 18. HEAD versus GET

print("\nExercițiul 18")
response_head = requests.head(BASE_URL, timeout=TIMEOUT)
response_get = requests.get(BASE_URL, timeout=TIMEOUT)

print("Lungime conținut HEAD:", len(response_head.content))
print("Lungime conținut GET:", len(response_get.content))

# Diferența: HEAD cere serverului să trimită doar antetele paginii, fără corpul HTML, de aceea lungimea e 0.
# GET aduce atât antetele cât și corpul întreg al paginii.

time.sleep(1)


# Exercițiul 19. Cookie-uri

print("\nExercițiul 19")
if not response.cookies:
    print("Niciun cookie setat de server.")
else:
    for cookie in response.cookies:
        print(f"Cookie: {cookie.name} | Secure: {cookie.secure}")


# Exercițiul 20. Sesiuni

print("\nExercițiul 20")
session = requests.Session()
session.headers.update({"User-Agent": "WebLab-CiubotaruDorian"})

response_session = session.get(ECHO_URL + "/headers", timeout=TIMEOUT)
print("Răspuns de la server (verificare User-Agent):")
print(response_session.text)