# Laborator: funcții, metode și importuri pe web
# Student: <Ciubotaru Dorian>

import time
import requests
import urllib.parse
import re
from html.parser import HTMLParser
import hashlib
import json
import socket
import ssl

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde


# Exercițiul 35. Descompunerea unui URL

print("\nExercițiul 35")
def parse_example_url():
    """Descompune un URL în componentele sale de bază."""
    parsed = urllib.parse.urlparse("https://cybercor.org/path?x=1#top")
    print("Scheme:", parsed.scheme)
    print("Netloc:", parsed.netloc)
    print("Path:", parsed.path)
    print("Query:", parsed.query)
    print("Fragment:", parsed.fragment)

parse_example_url()


# Exercițiul 36. Compunerea URL-urilor

print("\nExercițiul 36")
def join_urls():
    """Transformă legături relative în URL-uri complete, pornind de la BASE_URL."""
    links = ["/about", "contact.html", "../index.html"]
    for link in links:
        print(f"{link} -> {urllib.parse.urljoin(BASE_URL, link)}")

join_urls()


# Exercițiul 37. Extragerea legăturilor

print("\nExercițiul 37")
def extract_links(html: str) -> list:
    """Extrage toate legăturile (href) din HTML folosind expresii regulate, fără duplicate."""
    links = re.findall(r'href="([^"]+)"', html)
    # Folosim set() pentru a elimina duplicatele, apoi transformăm înapoi în listă
    return list(set(links))

response_html = requests.get(BASE_URL, timeout=TIMEOUT).text
legaturi_unice = extract_links(response_html)
print(f"S-au găsit {len(legaturi_unice)} legături unice pe pagina principală.")

time.sleep(1)


# Exercițiul 38. Interne sau externe?

print("\nExercițiul 38")
def split_links(links: list, domain: str) -> tuple:
    """Returnează două liste: legături pe același domeniu și legături externe."""
    interne = []
    externe = []
    for link in links:
        # Transformăm fiecare legătură într-un URL complet
        full_url = urllib.parse.urljoin(f"https://{domain}", link)
        # Verificăm dacă domeniul (netloc) se potrivește cu domeniul dat
        if urllib.parse.urlparse(full_url).netloc == domain:
            interne.append(full_url)
        else:
            externe.append(full_url)
    return interne, externe

interne, externe = split_links(legaturi_unice, "cybercor.org")
print(f"Legături interne: {len(interne)}")
print(f"Legături externe: {len(externe)}")


# Exercițiul 39. Propriile metode (Extragerea imaginilor cu HTMLParser)

print("\nExercițiul 39")
class ImageFinder(HTMLParser):
    def __init__(self):
        super().__init__()
        self.images = []

    def handle_starttag(self, tag, attrs):
        # Dacă tag-ul este de tip imagine (indiferent de majuscule)
        if tag.lower() == "img":
            # Găsim valoarea atributului 'src', sau None dacă nu există
            src = dict(attrs).get("src")
            if src is not None:
                self.images.append(src)

# 1. Testăm clasa folosind codul HTML din instrucțiuni
test_html = """
<html><body>
  <img src="/logo.png" alt="Logo">
  <IMG SRC="poza.jpg">
  <img alt="imagine fără src">
  <img src="https://cdn.example.com/banner.webp" />
  <a href="/despre">Aceasta nu este o imagine</a>
</body></html>
"""

finder = ImageFinder()
finder.feed(test_html)
print("Imagini găsite în test:", finder.images)

assert finder.images == [
    "/logo.png",                            # imagine obișnuită
    "poza.jpg",                             # tag scris cu majuscule
    "https://cdn.example.com/banner.webp",  # tag care se închide singur
], "Parserul nu a găsit exact imaginile așteptate"
print("Testul a trecut!")

# 2. Rulăm parserul pe site-ul real
finder_real = ImageFinder()
finder_real.feed(response_html) # folosim HTML-ul descărcat la exercițiul 37
print(f"\n{len(finder_real.images)} imagini găsite pe site-ul real:")
for img_src in finder_real.images:
    print(img_src)


# Exercițiul 40. Amprenta paginii

print("\nExercițiul 40")
def page_fingerprint(url: str) -> str:
    """Returnează amprenta SHA256 a conținutului paginii (în format hex)."""
    response = requests.get(url, timeout=TIMEOUT)
    return hashlib.sha256(response.content).hexdigest()

amprenta1 = page_fingerprint(BASE_URL)
time.sleep(1)
amprenta2 = page_fingerprint(BASE_URL)

print("Amprenta 1:", amprenta1)
print("Amprenta 2:", amprenta2)

# De ce ar putea fi diferite amprentele la două rulări succesive?
# Dacă serverul adaugă conținut dinamic în pagină (ex: un ceas, un timestamp, un ID unic generat pentru sesiune
# sau reclame care se schimbă la fiecare refresh), conținutul HTML se modifică subtil, iar amprenta SHA256 devine total diferită.

time.sleep(1)


# Exercițiul 41. Salvarea în JSON

print("\nExercițiul 41")
def save_and_load_headers(url: str):
    """Salvează antetele într-un fișier JSON și le încarcă înapoi pentru verificare."""
    response = requests.get(url, timeout=TIMEOUT)

    # Scriem antetele în fișier (le transformăm din requests structura în dict standard)
    with open("headers.json", "w") as file:
        json.dump(dict(response.headers), file, indent=2)

    # Încărcăm antetele din fișier
    with open("headers.json", "r") as file:
        loaded_headers = json.load(file)

    print("Afișăm antetul 'Content-Type' din fișierul JSON încărcat:")
    print(loaded_headers.get("Content-Type", "lipsește"))

save_and_load_headers(BASE_URL)

time.sleep(1)


# Exercițiul 42. Interogare DNS

print("\nExercițiul 42")
def resolve(hostname: str) -> str:
    """Returnează adresa IP a unui nume de domeniu folosind socket."""
    return socket.gethostbyname(hostname)

print("Adresa IP pentru cybercor.org este:", resolve("cybercor.org"))


# Exercițiul 43. Expirarea certificatului

print("\nExercițiul 43")
def cert_days_left(hostname: str) -> int:
    """Se conectează la portul 443 și returnează câte zile mai sunt valabile pe certificat."""
    context = ssl.create_default_context()
    with socket.create_connection((hostname, 443)) as sock:
        with context.wrap_socket(sock, server_hostname=hostname) as ssock:
            # Preluăm datele certificatului
            cert = ssock.getpeercert()
            # Extragem data de expirare ca string
            expire_str = cert["notAfter"]
            # Convertim în timestamp (secunde)
            expire_timestamp = ssl.cert_time_to_seconds(expire_str)
            # Calculăm diferența dintre expirare și momentul curent, în zile (86400 secunde pe zi)
            zile_ramase = (expire_timestamp - time.time()) / 86400
            return int(zile_ramase)

print(f"Certificatul pentru cybercor.org mai este valabil aproximativ: {cert_days_left('cybercor.org')} zile")


# Verificați-vǎ:
# În exercițiul 39, cine apelează metoda handle_starttag()?
# Noi nu o apelăm niciodată direct. Ea este apelată automat ("în culise") de metoda părinte .feed(),
# pe măsură ce aceasta parcurge rând cu rând codul HTML și se lovește de taguri de deschidere.
# Acesta este un exemplu de moștenire (inheritance) și programare condusă de evenimente (event-driven).