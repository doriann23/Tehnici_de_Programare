
# Laborator: funcții, metode și importuri pe web
# Student: <Ciubotaru Dorian>

import time

BASE_URL = "https://cybercor.org"
ECHO_URL = "https://httpbin.org"
TIMEOUT = 10  # secunde

# Exercițiul 1. Primul import

print("\nExercițiul 1")
import requests
import urllib.request

print("Versiunea requests:", requests.__version__)

# requests este o bibliotecă EXTERNĂ (scrisă de alții, nu vine cu Python),
# de aceea trebuie instalată cu pip install requests.
# urllib face parte din biblioteca standard, care este inclusă
# în Python la instalare, deci nu are nevoie de pip install.

time.sleep(1)


# Exercițiul 2. Două stiluri de import
print("\nExercițiul 2")

# Stilul 1: import requests
response = requests.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (import requests):", response.status_code)

# Stilul 2: from requests import get
from requests import get

response = get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (from requests import get):", response.status_code)

# Avantaj "import requests": se vede clar de unde vine funcția (requests.get),
# deci nu apar confuzii între nume la fel din module diferite.
# Avantaj "from requests import get": codul este mai scurt, scrii direct get().

time.sleep(1)


# Exercițiul 3. Alias-uri

print("\nExercițiul 3")
import requests as rq

response = rq.get(BASE_URL, timeout=TIMEOUT)
print("Cod de stare (rq.get):", response.status_code)

# Un alias face codul mai ușor de citit când numele modulului este lung sau
# este un alias folosit de toată lumea (ex: import numpy as np).
# Îl face mai greu de citit când alias-ul este ales aiurea sau prea scurt
# (ex: import requests as x), pentru că cine citește codul nu știe ce este x.

time.sleep(1)

# Exercițiul 4. Doar biblioteca standard

print("\nExercițiul 4")
# Site-ul răspunde 403 la User-Agent-ul implicit al urllib,
# de aceea trimitem un User-Agent propriu.
cerere = urllib.request.Request(BASE_URL, headers={"User-Agent": "WebLab-Student"})
with urllib.request.urlopen(cerere, timeout=TIMEOUT) as raspuns:
    print("Status:", raspuns.status)
    corp = raspuns.read().decode("utf-8")  # .read() dă octeți, decode îi face șir
    print(corp[:200])

time.sleep(1)

# Exercițiul 5. Priviți în interiorul unui modul

print("\nExercițiul 5")
print(dir(requests))

# Trei nume alese din rezultat:
# - get        -> este o funcție
# - Session    -> este o clasă
# - exceptions -> este un modul

# Exercițiul 6. Citiți documentația
print("\nExercițiul 6")
help(requests.get)

# Parametrul care setează timpul maxim de așteptare este timeout.
response = requests.get(BASE_URL, timeout=5)
print("Cerere cu timeout=5, status:", response.status_code)

time.sleep(1)

# Exercițiul 7. Cronometrarea unei cereri
print("\nExercițiul 7")
start = time.perf_counter()
response = requests.get(BASE_URL, timeout=TIMEOUT)
end = time.perf_counter()

print("Timp măsurat cu perf_counter:", round(end - start, 3), "secunde")
print("Timp response.elapsed:       ", response.elapsed.total_seconds(), "secunde")

# perf_counter măsoară tot timpul, inclusiv crearea conexiunii și lucrul
# bibliotecii, iar response.elapsed măsoară doar de la trimiterea cererii
# până la primirea antetelor răspunsului, deci este de obicei puțin mai mic.

# Exercițiul 8. Când un import eșuează

print("\nExercițiul 8")
try:
    import bs4
    print("bs4 este instalat, versiunea:", bs4.__version__)
except ImportError:
    print("Instalați modulul cu: pip install beautifulsoup4")


# Verificați-vă: modul vs pachet vs bibliotecă
# Modul      = un singur fișier .py care conține cod (ex: time.py).
# Pachet     = un director cu mai multe module (are __init__.py), ex: requests.
# Bibliotecă = termen general: o colecție de module/pachete care oferă funcționalități gata făcute (ex: biblioteca standard, requests).